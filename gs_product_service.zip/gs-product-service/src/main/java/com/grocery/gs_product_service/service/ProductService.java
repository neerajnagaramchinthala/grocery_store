package com.grocery.gs_product_service.service;

import com.grocery.gs_product_service.model.Product;
import java.util.List;

public interface ProductService {
    List<Product> getAllProducts();  // Get all products
    Product getProductById(Long id); // Get product by ID
    void saveProduct(Product product); // Save product (both add and update)
    void deleteProduct(Long id);  // Delete product by ID
}
