package com.grocery.gs_product_service.repository;

import com.grocery.gs_product_service.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
