package com.grocery.gs_product_service.service;

import com.grocery.gs_product_service.model.Order;
import com.grocery.gs_product_service.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public void saveOrder(Order order) {
        orderRepository.save(order);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();  // Fetching all orders
    }

    @Override
    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);  // Delete order by ID
    }
}
