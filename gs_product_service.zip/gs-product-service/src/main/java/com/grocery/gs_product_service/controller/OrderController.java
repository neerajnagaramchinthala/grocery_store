package com.grocery.gs_product_service.controller;

import com.grocery.gs_product_service.model.Order;
import com.grocery.gs_product_service.model.Product;
import com.grocery.gs_product_service.service.OrderService;
import com.grocery.gs_product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Controller
@RequestMapping("/products")
public class OrderController {

    @Autowired
    private ProductService productService;

    @Autowired
    private OrderService orderService;

    // Show the list of products for the user
    @GetMapping("/user/products")
    public String showProductList(@RequestParam String username, Model model) {
        model.addAttribute("username", username);
        model.addAttribute("products", productService.getAllProducts());
        return "user-product-list"; // Thymeleaf view for product list
    }

    // Handle order submission
    @PostMapping("/submit-order")
    public String submitOrder(@RequestParam String username,
                               @RequestParam("productIds") List<Long> productIds,
                               @RequestParam("quantities") List<Integer> quantities,
                               Model model) {

        List<String> selectedProducts = new ArrayList<>();
        int totalQty = 0;
        double totalPrice = 0.0;

        // Loop through the selected products and calculate total quantity and price
        for (int i = 0; i < productIds.size(); i++) {
            Integer qty = quantities.get(i);
            if (qty != null && qty > 0) {
                Product product = productService.getProductById(productIds.get(i));
                selectedProducts.add(product.getName() + " (x" + qty + ")");
                totalQty += qty;
                totalPrice += product.getPrice() * qty;
            }
        }

        // If no products were selected, show a message and redirect back to product list
        if (selectedProducts.isEmpty()) {
            model.addAttribute("message", "Please select at least one product.");
            return "redirect:/products/user/products?username=" + username;
        }

        // Create a new order
        Order order = new Order();
        order.setUsername(username);
        order.setProductNames(String.join(", ", selectedProducts));
        order.setQuantity(totalQty);
        order.setTotalAmount(totalPrice);

        // Save the order
        orderService.saveOrder(order);

        // Add order details to the model and return the order confirmation page
        model.addAttribute("order", order);
        return "order-confirmation"; // Order confirmation page
    }
}
