package com.grocery.gs_product_service.service;

import com.grocery.gs_product_service.model.Product;
import com.grocery.gs_product_service.repository.ProductRepository;
import com.grocery.gs_product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();  // Get all products from the database
    }

    @Override
    public Product getProductById(Long id) {
        return productRepository.findById(id).orElse(null);  // Get product by ID
    }

    @Override
    public void saveProduct(Product product) {
        productRepository.save(product);  // Save product (either add new or update)
    }

    @Override
    public void deleteProduct(Long id) {
        productRepository.deleteById(id);  // Delete product by ID
    }
}
