package com.grocery.gs_product_service.controller;

import com.grocery.gs_product_service.model.Product;
import com.grocery.gs_product_service.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/products")  // Admin route for product management
public class ProductController {

    @Autowired
    private ProductService productService;

    // Show all products
    @GetMapping("/manage")
    public String showAllProducts(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "admin-product-list"; // Thymeleaf view for product list
    }

    // Show the form for adding a new product
    @GetMapping("/add")
    public String showAddProductForm(Model model) {
        model.addAttribute("product", new Product());
        return "admin-add-product"; // Admin form for adding product
    }

    // Save a new product
    @PostMapping("/save")
    public String saveProduct(@ModelAttribute Product product) {
        productService.saveProduct(product);
        return "redirect:/admin/products/manage"; // Redirect to manage products
    }

    // Show the form for editing a product
    @GetMapping("/manage/edit/{id}")
    public String showEditProductForm(@PathVariable Long id, Model model) {
        Product product = productService.getProductById(id);
        model.addAttribute("product", product);
        return "admin-edit-product"; // Admin form for editing product
    }

    // Update an existing product
    @PostMapping("/manage/edit/{id}")
    public String updateProduct(@PathVariable Long id, @ModelAttribute Product product) {
        // Fetch the existing product by ID
        Product existingProduct = productService.getProductById(id);

        // Update the existing product's fields with the new values
        existingProduct.setName(product.getName());
        existingProduct.setPrice(product.getPrice());
        existingProduct.setQuantity(product.getQuantity());

        // Save the updated product
        productService.saveProduct(existingProduct);

        // Redirect to the product management page
        return "redirect:/admin/products/manage";
    }

    // Delete a product
    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return "redirect:/admin/products/manage"; // Redirect back to manage products
    }
}
