package com.grocery.gs_product_service.controller;

import com.grocery.gs_product_service.model.Order;
import com.grocery.gs_product_service.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/orders")  // Admin order management
public class AdminOrderController {

    @Autowired
    private OrderService orderService;

    // Show all orders for the admin
    @GetMapping("/manage")
    public String showAllOrders(Model model) {
        List<Order> orders = orderService.getAllOrders();  // Fetch all orders
        model.addAttribute("orders", orders);
        return "admin-order-list"; // Template for admin order list
    }

    // Delete an order (admin side)
    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable Long id) {
        orderService.deleteOrder(id);  // Delete the order by ID
        return "redirect:/admin/orders/manage"; // Redirect back to the orders list
    }
}

