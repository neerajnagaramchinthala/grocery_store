package com.grocery.gs_product_service.repository;

import com.grocery.gs_product_service.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
    // Additional custom query methods if needed
}
