package com.grocery.gs_product_service.service;

import com.grocery.gs_product_service.model.Order;
import java.util.List;

public interface OrderService {
    void saveOrder(Order order);
    List<Order> getAllOrders();
    void deleteOrder(Long id);
}
