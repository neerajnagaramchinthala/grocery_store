package com.grocery.gs_product_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsProductUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
