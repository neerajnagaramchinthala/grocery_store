package com.grocery.gs_user_service.service;

import com.grocery.gs_user_service.model.User;

public interface UserService {
    User authenticate(String username, String password);
    boolean existsByUsername(String username);
    void saveUser(User user);
}
